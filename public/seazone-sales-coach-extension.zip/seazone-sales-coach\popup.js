/* popup.js - Seazone Sales Coach Popup */

document.getElementById('toggle').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (tab?.id) {
    chrome.tabs.sendMessage(tab.id, { action: 'toggle-sidebar' });
  }
  window.close();
});

document.getElementById('open-app').addEventListener('click', () => {
  chrome.tabs.create({ url: 'https://real-time-closer.lovable.app/dashboard' });
  window.close();
});
