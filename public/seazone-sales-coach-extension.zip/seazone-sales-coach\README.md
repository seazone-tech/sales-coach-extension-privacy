# Seazone Sales Coach — Chrome Extension

Extensão Chrome (Manifest V3) que injeta um painel lateral de coaching de vendas em tempo real no Google Meet. **100% offline**, sem necessidade de API key.

## Funcionalidades

- 🎙️ **Transcrição ao vivo** via Web Speech API nativa do Chrome
- ⚠️ **Detecção de objeções** por palavras-chave com popup automático (8s):
  - "preço/caro" → Reforce preço de custo + valorização
  - "pensar" → Pergunte o que falta para decidir
  - "não tenho" → Explore financiamento
  - "cônjuge/esposa/marido" → Sugira incluir na próxima call
  - "concorrência/outro" → Diferencie gestão + liquidez
- ✅ **Detecção positiva** ("fechado", "aceito", etc.)
- 💡 **Silêncio > 30s** → Alerta para engajar o cliente
- 💾 **Persistência** no localStorage com timestamps

## Instalação

1. Abra `chrome://extensions` no Chrome
2. Ative **Modo do desenvolvedor** (canto superior direito)
3. Clique **Carregar sem compactação**
4. Selecione a pasta `chrome-extension/`
5. O ícone 🎯 aparece automaticamente no Google Meet

## Uso

1. Entre em uma reunião no Google Meet
2. Clique no 🎯 (ou `Alt+S`) para abrir o painel
3. Clique **▶ Iniciar Escuta** para começar a transcrição
4. Objeções e dicas aparecem automaticamente no painel de coaching

## Arquivos

| Arquivo | Descrição |
|---------|-----------|
| `manifest.json` | Configuração Manifest V3 |
| `content.js` | Injeta sidebar no Google Meet |
| `content.css` | Estilos do toggle e sidebar |
| `sidebar.html` | UI do painel (transcript 60% + coaching 40%) |
| `sidebar.js` | Web Speech API + detecção de objeções |
| `popup.html/js` | Popup da barra de ferramentas |
| `icons/` | Ícones da extensão |
