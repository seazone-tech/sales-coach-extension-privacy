(() => {
  const SIDEBAR_ID = "seazone-coach-sidebar";
  const TOGGLE_ID = "seazone-coach-toggle";

  if (document.getElementById(SIDEBAR_ID)) return;

  // ===== Interceptar getUserMedia para detectar mute real =====
  const pageScript = document.createElement("script");
  pageScript.textContent = `
    (function() {
      const originalGUM = navigator.mediaDevices.getUserMedia.bind(navigator.mediaDevices);
      navigator.mediaDevices.getUserMedia = async function(constraints) {
        const stream = await originalGUM(constraints);
        stream.getAudioTracks().forEach(track => {
          const descriptor = Object.getOwnPropertyDescriptor(MediaStreamTrack.prototype, 'enabled');
          let _enabled = track.enabled;
          Object.defineProperty(track, 'enabled', {
            get() { return _enabled; },
            set(val) {
              _enabled = val;
              descriptor.set.call(track, val);
              document.dispatchEvent(new CustomEvent('__seazone_mute__', { detail: { muted: !val } }));
            }
          });
        });
        return stream;
      };
    })();
  `;
  document.documentElement.prepend(pageScript);
  pageScript.remove();

  function waitForMeet(cb, max = 30) {
    let n = 0;
    const check = () => {
      n++;
      if (document.querySelector("video, [data-meeting-title], [data-call-id]") || n >= max) cb();
      else setTimeout(check, 1000);
    };
    check();
  }

  waitForMeet(() => {
    let isOpen = false;
    let isListening = false;

    function getLocalName() {
      const selectors = ["[data-self-name]", "[data-participant-id] [data-tooltip]", ".ZjFb7c", "[data-meeting-title]"];
      for (const sel of selectors) {
        const el = document.querySelector(sel);
        if (el) {
          const name = el.getAttribute("data-self-name") || el.getAttribute("data-tooltip") || el.textContent?.trim();
          if (name && name.length > 1 && name.length < 60) return name;
        }
      }
      return null;
    }

    let localNameSent = false;
    function trySendLocalName() {
      if (localNameSent) return;
      const name = getLocalName();
      if (name) {
        iframe.contentWindow?.postMessage({ type: "seazone-local-name", name }, "*");
        localNameSent = true;
      }
    }
    const nameInterval = setInterval(() => {
      trySendLocalName();
      if (localNameSent) clearInterval(nameInterval);
    }, 2000);

    // --- Toggle button ---
    const toggle = document.createElement("button");
    toggle.id = TOGGLE_ID;
    toggle.textContent = "🎯";
    toggle.title = "Seazone Sales Coach (Alt+S)";
    document.body.appendChild(toggle);

    // --- Sidebar (position:fixed, starts off-screen) ---
    const sidebar = document.createElement("div");
    sidebar.id = SIDEBAR_ID;
    sidebar.className = "seazone-collapsed";

    const iframe = document.createElement("iframe");
    iframe.src = chrome.runtime.getURL("sidebar.html");
    iframe.className = "seazone-sidebar-iframe";
    iframe.allow = "microphone; autoplay; display-capture";
    sidebar.appendChild(iframe);

    document.body.appendChild(sidebar);

    // ===== SPLIT LAYOUT: CSS-only, no DOM manipulation =====
    function activateSplitLayout() {
      // Spoof window.innerWidth so Google Meet recalculates tile layout to 75vw
      const originalInnerWidth = Object.getOwnPropertyDescriptor(window, "innerWidth");
      Object.defineProperty(window, "innerWidth", {
        get: () => Math.round(window.screen.width * 0.75),
        configurable: true,
      });
      window.dispatchEvent(new Event("resize"));
      isListening = true;
      console.log("[seazone] Split layout activated (innerWidth spoofed to 75%)");
    }

    function deactivateSplitLayout() {
      // Restore window.innerWidth to original
      delete window.innerWidth;
      window.dispatchEvent(new Event("resize"));
      isListening = false;
      console.log("[seazone] Split layout deactivated (innerWidth restored)");
    }

    function open() {
      sidebar.classList.replace("seazone-collapsed", "seazone-expanded");
      toggle.classList.add("seazone-toggle-hidden");
      isOpen = true;
      chrome.storage?.local?.set({ sidebarOpen: true });
    }

    function close() {
      if (isListening) deactivateSplitLayout();
      sidebar.classList.replace("seazone-expanded", "seazone-collapsed");
      toggle.classList.remove("seazone-toggle-hidden");
      isOpen = false;
      chrome.storage?.local?.set({ sidebarOpen: false });
    }

    function sendMuteToSidebar(isMuted) {
      iframe.contentWindow?.postMessage({ type: "seazone-mute", isMuted }, "*");
    }

    // --- Events ---
    toggle.addEventListener("click", open);

    window.addEventListener("message", (e) => {
      if (e.data?.type === "seazone-close") close();
      if (e.data?.type === "seazone-status") {
        e.data.listening ? activateSplitLayout() : deactivateSplitLayout();
      }
    });

    chrome.storage?.local?.get("sidebarOpen", (r) => {
      if (r.sidebarOpen) open();
    });

    // ===== Mute Detection =====
    let lastMuteState = null;

    document.addEventListener("__seazone_mute__", (e) => {
      const muted = e.detail.muted;
      if (muted !== lastMuteState) {
        lastMuteState = muted;
        sendMuteToSidebar(muted);
      }
    });

    const MUTE_SELECTORS = [
      "button[data-is-muted]",
      'button[aria-label*="microfone"]',
      'button[aria-label*="microphone"]',
      'button[aria-label*="Ativar mic"]',
      'button[aria-label*="Desativar mic"]',
      'button[aria-label*="Turn off mic"]',
      'button[aria-label*="Turn on mic"]',
      'button[aria-label*="Unmute"]',
      'button[data-tooltip*="microfone"]',
    ];

    function detectMuteFromUI() {
      const btn = document.querySelector(MUTE_SELECTORS.join(", "));
      if (!btn) return;
      const isMuted =
        btn.getAttribute("data-is-muted") === "true" ||
        btn.getAttribute("aria-pressed") === "true" ||
        /Ativar|Turn on|Unmute/i.test(btn.getAttribute("aria-label") || "");
      if (isMuted !== lastMuteState) {
        lastMuteState = isMuted;
        sendMuteToSidebar(isMuted);
      }
    }

    setInterval(detectMuteFromUI, 800);
    const muteObserver = new MutationObserver(detectMuteFromUI);
    muteObserver.observe(document.body, {
      attributes: true,
      subtree: true,
      attributeFilter: ["data-is-muted", "aria-label", "aria-pressed"],
    });

    // ===== Active Speaker Detection =====
    const SPEAKER_SELECTORS = [".zWGUib", '[data-speaking="true"]', ".KV1GEc"];
    let lastActiveSpeaker = null;

    function detectActiveSpeaker() {
      for (const sel of SPEAKER_SELECTORS) {
        const el = document.querySelector(sel);
        if (el) {
          const name =
            el.getAttribute("data-tooltip") ||
            el.getAttribute("aria-label") ||
            el.closest("[data-participant-id]")?.querySelector("[data-tooltip]")?.getAttribute("data-tooltip") ||
            el.textContent?.trim();
          if (name && name.length > 1 && name.length < 60 && name !== lastActiveSpeaker) {
            lastActiveSpeaker = name;
            iframe.contentWindow?.postMessage({ type: "seazone-speaker", name }, "*");
          }
          return;
        }
      }
    }

    const speakerObserver = new MutationObserver(detectActiveSpeaker);
    speakerObserver.observe(document.body, {
      childList: true,
      subtree: true,
      attributes: true,
      attributeFilter: ["data-speaking", "class", "aria-label"],
    });
    setInterval(detectActiveSpeaker, 2000);

    // ===== Participant Email Detection =====
    function detectParticipantEmails() {
      const emails = new Set();
      // Google Meet exposes participant emails via data-hovercard-id or data-participant-id
      document.querySelectorAll('[data-hovercard-id]').forEach(el => {
        const hid = el.getAttribute('data-hovercard-id');
        if (hid && hid.includes('@')) emails.add(hid);
      });
      // Also check participant panels
      document.querySelectorAll('[data-participant-id]').forEach(el => {
        const pid = el.getAttribute('data-participant-id');
        if (pid && pid.includes('@')) emails.add(pid);
      });
      // Check aria-label containing emails
      document.querySelectorAll('[aria-label*="@"]').forEach(el => {
        const label = el.getAttribute('aria-label') || '';
        const emailMatch = label.match(/[\w.+-]+@[\w.-]+\.\w{2,}/g);
        if (emailMatch) emailMatch.forEach(e => emails.add(e));
      });
      if (emails.size > 0) {
        iframe.contentWindow?.postMessage({ type: "seazone-participant-emails", emails: [...emails] }, "*");
      }
    }

    // Detect emails periodically
    setInterval(detectParticipantEmails, 5000);

    chrome.runtime?.onMessage?.addListener((msg) => {
      if (msg.action === "toggle-sidebar") isOpen ? close() : open();
    });

    document.addEventListener("keydown", (e) => {
      if (e.altKey && e.key === "s") {
        e.preventDefault();
        isOpen ? close() : open();
      }
    });
  });
})();
