(() => {
  // ===== Config =====
  const SUPABASE_URL = 'https://ussfqmqwyavjsqngtztl.supabase.co';
  const SUPABASE_ANON_KEY = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InVzc2ZxbXF3eWF2anNxbmd0enRsIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzMwODU0ODIsImV4cCI6MjA4ODY2MTQ4Mn0.jSvWMwo6tz_1gt-bd1_mjfAneNQ29s9u3rUHfSBNKVI';
  const WHISPER_URL = 'https://hub.seazone.dev/v1/audio/transcriptions';
  const WHISPER_KEY = 'sk-quUjupD-rYAMgUvOL853MA';
  const CHUNK_DURATION_MS = 15000;

  // ===== DOM References =====
  const transcriptEl = document.getElementById('transcript');
  const transcriptEmpty = document.getElementById('transcript-empty');
  const popupsEl = document.getElementById('popups');
  const popupsEmpty = document.getElementById('popups-empty');
  const btnListen = document.getElementById('btn-listen');
  const btnListenIcon = document.getElementById('btn-listen-icon');
  const btnListenLabel = document.getElementById('btn-listen-label');
  const btnClear = document.getElementById('btn-clear');
  const btnClose = document.getElementById('btn-close');
  const btnConclude = document.getElementById('btn-conclude');
  const perfScore = document.getElementById('perf-score');
  const scoreBarFill = document.getElementById('score-bar-fill');
  const badgeMic = document.getElementById('badge-mic');
  const badgeTab = document.getElementById('badge-tab');

  // ===== Helper Functions =====
  function formatTime(date) {
    return date.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
  }

  function updateBadge(type, active) {
    const el = type === 'mic' ? badgeMic : badgeTab;
    if (!el) return;
    if (active) {
      el.classList.add('active');
      el.classList.remove('inactive');
    } else {
      el.classList.remove('active');
      el.classList.add('inactive');
    }
  }

  function getSessionKey() {
    const dateStr = new Date(sessionStart).toISOString().split('T')[0];
    return `seazone_session_${dateStr}_${sessionStart}`;
  }

  // ===== Objection Rules =====
  const objectionRules = [
    { keywords: ['muito caro', 'caro demais', 'preço alto', 'fora do orçamento'], label: 'Objeção de Preço', message: 'Destaque o retorno sobre investimento e a valorização do imóvel.' },
    { keywords: ['vou pensar', 'preciso pensar', 'deixa eu pensar'], label: 'Objeção de Tempo', message: 'Crie urgência: mencione disponibilidade limitada ou condições especiais.' },
    { keywords: ['não confio', 'fraude', 'golpe', 'não é seguro'], label: 'Objeção de Confiança', message: 'Apresente cases de sucesso, depoimentos e garantias contratuais.' },
    { keywords: ['não tenho interesse', 'não é para mim', 'não quero'], label: 'Objeção de Interesse', message: 'Reformule a proposta de valor. Pergunte o que o cliente busca.' },
    { keywords: ['muito arriscado', 'risco alto', 'arriscado demais'], label: 'Objeção de Risco', message: 'Mostre dados históricos de rentabilidade e segurança do investimento.' },
    { keywords: ['já tenho', 'já invisto', 'já possuo'], label: 'Objeção de Concorrência', message: 'Diferencial: gestão completa, sem dor de cabeça, rentabilidade superior.' },
    { keywords: ['não entendi', 'como funciona', 'explica melhor'], label: 'Pedido de Clareza', message: 'Simplifique a explicação. Use analogias e exemplos práticos.' },
  ];

  // ===== Positive Keywords =====
  const positiveKeywords = [
    'interessante', 'adorei', 'quero', 'excelente', 'perfeito',
    'ótimo', 'vamos fechar', 'fechado', 'combinado', 'me manda',
    'gostei muito', 'maravilhoso', 'onde assino', 'estou convencido',
  ];

  // ===== State =====
  let isListening = false;
  let silenceTimer = null;
  let sessionStart = null;
  let transcriptEntries = [];
  let lastSpeaker = null;
  let localParticipantName = null; // Name from Meet UI
  let activeSpeakerName = null; // Name from Meet speaker detection
  let participantEmails = []; // Emails from Meet participants
  // -- Mic (Vendedor) --
  let micRecognition = null;
  let micActive = false;
  let isMicMuted = false;

  // -- Tab audio (Cliente) --
  let tabStream = null;
  let tabRecorder = null;
  let tabActive = false;

  // ===== AI Sentiment =====
  let sentimentInterval = null;
  let aiSentimentScore = 0;
  let aiSentimentLabel = 'neutral';

  function renderSentimentCard() {
    const emojiEl = document.getElementById('sentiment-emoji');
    const labelEl = document.getElementById('sentiment-label');
    if (!emojiEl || !labelEl) return;

    if (aiSentimentScore >= 3) {
      emojiEl.textContent = '😊';
      emojiEl.className = 'sentiment-emoji positive';
      labelEl.textContent = 'Investidor interessado';
      labelEl.className = 'sentiment-label positive';
    } else if (aiSentimentScore <= -3) {
      emojiEl.textContent = '😟';
      emojiEl.className = 'sentiment-emoji negative';
      labelEl.textContent = 'Investidor resistente';
      labelEl.className = 'sentiment-label negative';
    } else {
      emojiEl.textContent = '😐';
      emojiEl.className = 'sentiment-emoji neutral';
      labelEl.textContent = 'Investidor neutro';
      labelEl.className = 'sentiment-label neutral';
    }
  }

  function startSentimentAI() {
    if (sentimentInterval) clearInterval(sentimentInterval);
    sentimentInterval = setInterval(async () => {
      const clienteLines = transcriptEntries
        .filter(e => e.speaker === 'Cliente')
        .slice(-10)
        .map(e => e.text)
        .join(' ');
      if (!clienteLines || clienteLines.length < 10) return;

      try {
        const res = await fetch(`${SUPABASE_URL}/functions/v1/analyze-sentiment`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'apikey': SUPABASE_ANON_KEY,
            'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
          },
          body: JSON.stringify({ text: clienteLines }),
        });
        if (!res.ok) return;
        const data = await res.json();
        if (data.score !== undefined) {
          aiSentimentScore = data.score;
          aiSentimentLabel = data.label || 'neutral';
          renderSentimentCard();
        }
      } catch (e) {
        console.warn('[sentiment] AI analysis failed:', e);
      }
    }, 30000); // Every 30 seconds
  }

  function stopSentimentAI() {
    if (sentimentInterval) {
      clearInterval(sentimentInterval);
      sentimentInterval = null;
    }
  }

  // ===== Sentiment / Interest Thermometer =====
  const sentimentKeywords = {
    positive: ['interessante', 'adorei', 'quero', 'excelente', 'perfeito', 'ótimo',
      'bom preço', 'me manda', 'vamos fechar', 'fechado', 'combinado',
      'estou convencido', 'fiquei interessado', 'gostei', 'maravilhoso', 'incrível'],
    negative: ['não gostei', 'muito caro', 'impossível', 'não vejo', 'problema', 'não faz sentido',
      'não confio', 'fraude', 'esquece', 'não quero',
      'não é para mim', 'muito arriscado', 'não tenho interesse', 'desisto', 'absurdo'],
    neutral: ['entendi', 'ok', 'hmm', 'vou pensar', 'talvez', 'quem sabe', 'pode ser']
  };
  let sentimentScore = 0;

  function updateSentiment(text, speaker) {
    // Skip if speaker is the local participant (seller) or Seazone
    const isSeller = speaker === localParticipantName || speaker === 'Vendedor' || (speaker || '').toLowerCase().includes('seazone');
    if (isSeller) return;
    const lower = text.toLowerCase();
    let delta = 0;
    sentimentKeywords.positive.forEach(kw => { if (lower.includes(kw)) delta += 2; });
    sentimentKeywords.negative.forEach(kw => { if (lower.includes(kw)) delta -= 2; });
    sentimentKeywords.neutral.forEach(kw => { if (lower.includes(kw)) delta += 0; });
    if (delta === 0) return;
    sentimentScore = Math.max(-10, Math.min(10, sentimentScore + delta));
    renderThermometer();

    // Show popup for extreme changes
    if (sentimentScore >= 7) {
      showPopup('positive', '🔥', 'Interesse Alto!', 'O investidor está engajado. Avance para o fechamento!', 6000);
    } else if (sentimentScore <= -5) {
      showPopup('objection', '🥶', 'Interesse Baixo', 'O investidor parece resistente. Tente mudar a abordagem.', 6000);
    }
  }

  function renderThermometer() {
    const el = document.getElementById('thermometer-fill');
    const label = document.getElementById('thermometer-label');
    const emoji = document.getElementById('thermometer-emoji');
    if (!el || !label) return;

    // Map -10..+10 to 0..100%
    const pct = Math.round(((sentimentScore + 10) / 20) * 100);
    el.style.width = `${pct}%`;

    // Color based on score
    if (sentimentScore >= 5) {
      el.className = 'thermometer-fill hot';
      emoji.textContent = '🔥';
      label.textContent = `+${sentimentScore}`;
    } else if (sentimentScore >= 1) {
      el.className = 'thermometer-fill warm';
      emoji.textContent = '😊';
      label.textContent = `+${sentimentScore}`;
    } else if (sentimentScore <= -5) {
      el.className = 'thermometer-fill cold';
      emoji.textContent = '🥶';
      label.textContent = `${sentimentScore}`;
    } else if (sentimentScore <= -1) {
      el.className = 'thermometer-fill cool';
      emoji.textContent = '😐';
      label.textContent = `${sentimentScore}`;
    } else {
      el.className = 'thermometer-fill neutral';
      emoji.textContent = '😶';
      label.textContent = '0';
    }
  }

  // ===== Dynamic Template & Checklist =====
  let activeTemplate = null;
  let dynamicChecklistState = {}; // key: index, value: boolean
  let dynamicChecklistItems = []; // [{label, section, weight}]
  let templateLoaded = false;

  // Fallback hardcoded checklist (used if no template found)
  const fallbackChecklist = [
    { label: 'Perguntou sobre necessidades', section: 'Abertura de Reunião', weight: 1 },
    { label: 'Apresentou benefícios', section: 'Desenvolvimento', weight: 1 },
    { label: 'Discutiu preço', section: 'Negociação', weight: 1 },
    { label: 'Tratou objeções', section: 'Negociação', weight: 1 },
    { label: 'Definiu próximos passos', section: 'Fechamento', weight: 1 },
  ];

  const fallbackKeywords = {
    0: ['necessidade', 'precisa', 'busca', 'objetivo', 'o que você', 'procura'],
    1: ['benefício', 'diferencial', 'vantagem', 'exclusivo', 'valorização', 'rentabilidade'],
    2: ['preço', 'valor', 'investimento', 'custo', 'parcela', 'financiamento'],
    3: ['objeção', 'caro', 'pensar', 'não tenho'],
    4: ['próximo passo', 'agendar', 'enviar proposta', 'contrato', 'fechar'],
  };

  async function fetchTemplate(name) {
    const loadingEl = document.getElementById('checklist-loading');
    if (loadingEl) loadingEl.style.display = 'block';

    try {
      const res = await fetch(`${SUPABASE_URL}/functions/v1/get-extension-template`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'apikey': SUPABASE_ANON_KEY,
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify({ participantName: name || 'Vendedor' }),
      });

      if (!res.ok) throw new Error(`HTTP ${res.status}`);
      const data = await res.json();

      if (data.template && data.template.checklist_items?.length > 0) {
        activeTemplate = data.template;
        dynamicChecklistItems = data.template.checklist_items;
        console.log('[template] Loaded:', data.template.name, '—', dynamicChecklistItems.length, 'items');

        // Update header with template name
        const nameLabel = document.getElementById('template-name-label');
        if (nameLabel) nameLabel.textContent = data.template.name;
      } else {
        console.warn('[template] No template found, using fallback');
        dynamicChecklistItems = fallbackChecklist;
      }
    } catch (err) {
      console.error('[template] Fetch failed:', err);
      dynamicChecklistItems = fallbackChecklist;
    } finally {
      if (loadingEl) loadingEl.style.display = 'none';
      templateLoaded = true;
      initChecklist();
    }
  }

  function initChecklist() {
    dynamicChecklistState = {};
    dynamicChecklistItems.forEach((_, i) => { dynamicChecklistState[i] = false; });
    renderDynamicChecklist();
    updateScore();
  }

  const SECTION_ORDER = ['Abertura de Reunião', 'Desenvolvimento', 'Negociação', 'Fechamento'];
  const SECTION_DOTS = { 'Abertura de Reunião': 'abertura', 'Desenvolvimento': 'desenvolvimento', 'Negociação': 'negociacao', 'Fechamento': 'fechamento' };
  const SECTION_ICONS = { 'Abertura de Reunião': '🟦', 'Desenvolvimento': '🟨', 'Negociação': '🟧', 'Fechamento': '🟩' };

  function renderDynamicChecklist() {
    const container = document.getElementById('checklist-sections');
    if (!container) return;
    container.innerHTML = '';

    // Group by section
    const grouped = {};
    dynamicChecklistItems.forEach((item, idx) => {
      const section = item.section || 'Outros';
      if (!grouped[section]) grouped[section] = [];
      grouped[section].push({ ...item, idx });
    });

    // Render in order
    const orderedSections = SECTION_ORDER.filter(s => grouped[s]);
    // Add any extra sections not in order
    Object.keys(grouped).forEach(s => { if (!orderedSections.includes(s)) orderedSections.push(s); });

    for (const section of orderedSections) {
      const items = grouped[section];
      const sectionDiv = document.createElement('div');
      sectionDiv.className = 'checklist-section';

      const dotClass = SECTION_DOTS[section] || '';
      sectionDiv.innerHTML = `<div class="checklist-section-label"><span class="section-dot ${dotClass}"></span>${section}</div>`;

      const ul = document.createElement('ul');
      ul.className = 'checklist';

      for (const item of items) {
        const li = document.createElement('li');
        li.className = `checklist-item${dynamicChecklistState[item.idx] ? ' done' : ''}`;
        li.setAttribute('data-idx', item.idx);
        li.innerHTML = `<span class="check-icon">${dynamicChecklistState[item.idx] ? '✅' : '⬜'}</span><span>${item.label}</span>`;
        // Allow manual toggle on click
        li.addEventListener('click', () => {
          dynamicChecklistState[item.idx] = !dynamicChecklistState[item.idx];
          li.classList.toggle('done');
          li.querySelector('.check-icon').textContent = dynamicChecklistState[item.idx] ? '✅' : '⬜';
          updateScore();
          if (dynamicChecklistState[item.idx]) {
            showPopup('checklist-done', '📋', 'Checklist', `"${item.label}" concluído!`, 4000);
          }
        });
        ul.appendChild(li);
      }

      sectionDiv.appendChild(ul);
      container.appendChild(sectionDiv);
    }
  }

  // ===== Checklist auto-detection via AI analysis =====
  function updateChecklist(text) {
    if (!templateLoaded) return;
    const lower = text.toLowerCase();
    let changed = false;

    // If we have trigger_words from template, use them for basic matching
    if (activeTemplate?.trigger_words?.length > 0) {
      // Simple: mark items whose labels partially match transcript text
      dynamicChecklistItems.forEach((item, idx) => {
        if (dynamicChecklistState[idx]) return;
        const labelWords = item.label.toLowerCase().split(/\s+/).filter(w => w.length > 3);
        const matchCount = labelWords.filter(w => lower.includes(w)).length;
        if (matchCount >= 2 || (labelWords.length <= 2 && matchCount >= 1)) {
          dynamicChecklistState[idx] = true;
          changed = true;
          markChecklistItemByIdx(idx);
          showPopup('checklist-done', '📋', 'Checklist', `"${item.label}" concluído!`, 5000);
        }
      });
    } else {
      // Fallback keyword matching
      dynamicChecklistItems.forEach((item, idx) => {
        if (dynamicChecklistState[idx]) return;
        const kws = fallbackKeywords[idx] || [];
        if (kws.some(kw => lower.includes(kw))) {
          dynamicChecklistState[idx] = true;
          changed = true;
          markChecklistItemByIdx(idx);
          showPopup('checklist-done', '📋', 'Checklist', `"${item.label}" concluído!`, 5000);
        }
      });
    }

    if (changed) updateScore();
  }

  function markChecklistItemByIdx(idx) {
    const item = document.querySelector(`.checklist-item[data-idx="${idx}"]`);
    if (item) {
      item.classList.add('done');
      item.querySelector('.check-icon').textContent = '✅';
    }
  }

  function updateScore() {
    const total = dynamicChecklistItems.length;
    if (total === 0) { perfScore.textContent = '0%'; return; }

    // Weighted score
    let totalWeight = 0;
    let doneWeight = 0;
    dynamicChecklistItems.forEach((item, idx) => {
      const w = item.weight || 1;
      totalWeight += w;
      if (dynamicChecklistState[idx]) doneWeight += w;
    });

    const pct = totalWeight > 0 ? Math.round((doneWeight / totalWeight) * 100) : 0;
    perfScore.textContent = `${pct}%`;
    scoreBarFill.style.width = `${pct}%`;
    const cls = pct >= 80 ? 'high' : pct >= 40 ? 'mid' : '';
    perfScore.className = `perf-score ${cls}`;
    scoreBarFill.className = `score-bar-fill ${cls}`;
  }

  function resetChecklist() {
    dynamicChecklistItems.forEach((_, idx) => { dynamicChecklistState[idx] = false; });
    renderDynamicChecklist();
    updateScore();
  }

  // Fetch template immediately (will retry when localParticipantName is set)
  fetchTemplate(null);

  // ===== Transcript =====
  function addTranscriptLine(text, speaker = null, isFinal = true, isRefined = false) {
    if (!text.trim()) return;
    transcriptEmpty.style.display = 'none';

    const now = new Date();
    const entry = { text: text.trim(), speaker, timestamp: now.toISOString(), isFinal, isRefined };
    if (isFinal) {
      transcriptEntries.push(entry);
      lastSpeaker = speaker;
      saveToLocalStorage();
    }

    // Determine if this is the seller or a client
    const isSeller = speaker === 'Vendedor' || speaker === localParticipantName;
    const interimClass = isSeller ? 'interim-vendedor' : 'interim-cliente';
    transcriptEl.querySelectorAll(`.${interimClass}`).forEach(el => el.remove());

    const speakerClass = isSeller ? 'vendedor' : 'cliente';
    const speakerIcon = isSeller ? '🎤' : '👤';
    const displayName = isSeller && localParticipantName ? localParticipantName : (speaker || 'Cliente');
    const aiBadge = isRefined ? '<span class="ai-badge">✨ IA</span>' : '';

    const line = document.createElement('div');
    const classes = ['transcript-line', speakerClass];
    if (!isFinal) classes.push('interim', interimClass);
    line.className = classes.join(' ');

    line.innerHTML = `
      <div class="bubble">
        <div class="bubble-header">
          <span class="speaker">${speakerIcon} ${displayName || ''}</span>
          <span class="timestamp">${formatTime(now)}</span>
          ${aiBadge}
        </div>
        <span class="text">${text.trim()}</span>
      </div>`;
    transcriptEl.appendChild(line);
    transcriptEl.scrollTop = transcriptEl.scrollHeight;

    if (isFinal) {
      const lower = text.toLowerCase();
      checkObjections(lower);
      checkPositive(lower);
      updateChecklist(text);
      updateSentiment(text, speaker);
      resetSilenceTimer();
    }
  }

  // ===== Objection Detection =====
  function checkObjections(text) {
    for (const rule of objectionRules) {
      if (rule.keywords.some(kw => text.includes(kw))) {
        showPopup('objection', '⚠️', rule.label, rule.message, 8000);
        // Objection detected - no specific checklist item to mark
        return;
      }
    }
  }

  function checkPositive(text) {
    if (positiveKeywords.some(kw => text.includes(kw))) {
      showPopup('positive', '✅', 'Mandou bem!', 'Ponto registrado', 6000);
    }
  }

  // ===== Silence Detection =====
  function resetSilenceTimer() {
    clearTimeout(silenceTimer);
    if (isListening) {
      silenceTimer = setTimeout(() => {
        showPopup('silence', '💡', 'Silêncio detectado', 'Faça uma pergunta para engajar o cliente', 8000);
      }, 30000);
    }
  }

  // ===== Popups =====
  let activePopups = 0;
  const MAX_POPUPS = 3;

  function showPopup(type, icon, label, message, duration = 8000) {
    if (activePopups >= MAX_POPUPS) return;
    popupsEmpty.style.display = 'none';
    activePopups++;

    const popup = document.createElement('div');
    popup.className = `popup ${type}`;
    popup.innerHTML = `
      <div class="icon">${icon}</div>
      <div class="content">
        <span class="label">${label}</span>
        <span class="message">${message}</span>
      </div>
      <div class="progress-bar" style="animation-duration: ${duration}ms"></div>
    `;
    popupsEl.prepend(popup);

    setTimeout(() => {
      popup.classList.add('popup-exit');
      setTimeout(() => {
        popup.remove();
        activePopups--;
        if (activePopups === 0 && popupsEl.querySelectorAll('.popup').length === 0) {
          popupsEmpty.style.display = '';
        }
      }, 300);
    }, duration);
  }

  // =============================================
  // CHANNEL 1: Microphone → Web Speech API → "Vendedor"
  // =============================================
  let micWatchdog = null;
  let lastMicActivity = 0;

  function startMicRecognition() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      showPopup('objection', '⚠️', 'Erro', 'Web Speech API não disponível neste navegador', 5000);
      return;
    }

    function createRecognition() {
      const rec = new SpeechRecognition();
      rec.lang = 'pt-BR';
      rec.continuous = true;
      rec.interimResults = true;

      rec.onstart = () => {
        micActive = true;
        lastMicActivity = Date.now();
        updateBadge('mic', true);
        console.log('[mic] Speech recognition started');
      };

      rec.onresult = (event) => {
        lastMicActivity = Date.now();
        for (let i = event.resultIndex; i < event.results.length; i++) {
          const result = event.results[i];
          addTranscriptLine(result[0].transcript, localParticipantName || 'Vendedor', result.isFinal);
        }
      };

      rec.onerror = (event) => {
        console.warn('[mic] Speech recognition error:', event.error);
        if (event.error === 'not-allowed') {
          showPopup('objection', '⚠️', 'Microfone bloqueado', 'Permita o acesso ao microfone nas configurações', 8000);
          micActive = false;
          updateBadge('mic', false);
          return;
        }
        // For recoverable errors, mark as inactive — watchdog will restart
        micActive = false;
      };

      rec.onend = () => {
        micActive = false;
        // Immediate restart attempt for quick recovery
        if (isListening && !isMicMuted) {
          setTimeout(() => {
            if (isListening && !isMicMuted && !micActive) {
              console.log('[mic] Restarting after onend...');
              try { micRecognition.start(); } catch (e) {
                // If start fails, recreate the recognition object
                console.warn('[mic] Restart failed, recreating...');
                micRecognition = createRecognition();
                try { micRecognition.start(); } catch (e2) {}
              }
            }
          }, 300);
        } else {
          updateBadge('mic', false);
        }
      };

      return rec;
    }

    micRecognition = createRecognition();
    try { micRecognition.start(); } catch (e) { console.error('[mic] Failed to start:', e); }

    // Watchdog: check every 5s if mic should be active but isn't, and restart
    if (micWatchdog) clearInterval(micWatchdog);
    micWatchdog = setInterval(() => {
      const stale = Date.now() - lastMicActivity > 5000; // 5s without any activity
      const shouldBeActive = isListening && !isMicMuted;
      if (shouldBeActive && (!micActive || stale)) {
        console.warn('[mic] Watchdog: restarting (active=' + micActive + ', stale=' + stale + ')');
        try { micRecognition?.stop(); } catch (e) {}
        micRecognition = createRecognition();
        try { micRecognition.start(); } catch (e) {
          console.error('[mic] Watchdog restart failed:', e);
        }
      }
    }, 5000);
  }

  function stopMicRecognition() {
    if (micWatchdog) { clearInterval(micWatchdog); micWatchdog = null; }
    try { micRecognition?.stop(); } catch (e) {}
    micRecognition = null;
    micActive = false;
    updateBadge('mic', false);
  }

  // =============================================
  // CHANNEL 2: Tab Audio -> getDisplayMedia -> MediaRecorder -> Whisper -> "Cliente"
  // =============================================
  // getDisplayMedia is called on demand when user clicks start

  async function startTabCapture() {
    try {
      console.log('[tab] Requesting display media for tab audio...');
      // getDisplayMedia does NOT mute the tab audio
      tabStream = await navigator.mediaDevices.getDisplayMedia({
        video: true,  // Required by spec, we discard it immediately
        audio: true,
        preferCurrentTab: true,
      });

      // Discard video track — we only need audio
      tabStream.getVideoTracks().forEach(t => t.stop());

      if (tabStream.getAudioTracks().length === 0) {
        throw new Error('No audio track in shared stream');
      }

      tabActive = true;
      updateBadge('tab', true);
      console.log('[tab] Tab audio capture started via getDisplayMedia');

      // Auto-reconnect when stream track ends
      tabStream.getAudioTracks().forEach(track => {
        track.addEventListener('ended', () => {
          console.warn('[tab] Audio track ended');
          tabActive = false;
          updateBadge('tab', false);
        });
      });

      startTabRecording();
    } catch (err) {
      console.error('[tab] getDisplayMedia failed:', err.message);
      tabActive = false;
      updateBadge('tab', false);
      if (err.name === 'NotAllowedError') {
        showPopup('silence', '💡', 'Compartilhamento negado',
          'Aceite o compartilhamento da aba para capturar o áudio do cliente.', 6000);
      } else {
        showPopup('silence', '💡', 'Áudio do cliente indisponível',
          'Apenas o microfone será usado. Motivo: ' + err.message, 5000);
      }
    }
  }

  function startTabRecording() {
    if (!tabStream || !tabStream.active) return;

    const mimeType = MediaRecorder.isTypeSupported('audio/webm;codecs=opus')
      ? 'audio/webm;codecs=opus' : 'audio/webm';

    tabRecorder = new MediaRecorder(tabStream, { mimeType });
    let chunks = [];

    tabRecorder.ondataavailable = (e) => {
      if (e.data.size > 0) chunks.push(e.data);
    };

    tabRecorder.onstop = async () => {
      if (chunks.length === 0) return;
      const blob = new Blob(chunks, { type: mimeType });
      chunks = [];

      await transcribeTabChunk(blob, mimeType);

      if (isListening && tabStream?.active) {
        startTabRecording();
      }
    };

    tabRecorder.start();

    setTimeout(() => {
      if (tabRecorder?.state === 'recording') {
        tabRecorder.stop();
      }
    }, CHUNK_DURATION_MS);
  }

  async function transcribeTabChunk(blob, mimeType) {
    try {
      // Send audio directly to Whisper via Seazone LLMHub (OpenAI-compatible)
      const formData = new FormData();
      const ext = mimeType.includes('webm') ? 'webm' : 'ogg';
      formData.append('file', blob, `audio.${ext}`);
      formData.append('model', 'whisper-1');
      formData.append('language', 'pt');
      formData.append('response_format', 'json');

      const res = await fetch(WHISPER_URL, {
        method: 'POST',
        headers: {
          'Authorization': 'Bearer ' + WHISPER_KEY,
        },
        body: formData,
      });

      if (!res.ok) {
        console.error('[tab] Transcription failed:', res.status, await res.text().catch(() => ''));
        return;
      }

      const data = await res.json();
      if (data.text && data.text.trim()) {
        const speakerLabel = activeSpeakerName || 'Cliente';
        addTranscriptLine(data.text.trim(), speakerLabel, true, true);
        console.log('[tab] Transcribed:', data.text.trim().substring(0, 50) + '...');
      }
    } catch (err) {
      console.error('[tab] Transcription error:', err);
    }
  }

  function stopTabCapture() {
    try { tabRecorder?.stop(); } catch (e) {}
    tabRecorder = null;
    tabStream?.getTracks().forEach(t => t.stop());
    tabStream = null;
    tabActive = false;
    updateBadge('tab', false);
  }


  // ===== Controls =====
  function startListening() {
    isListening = true;
    sessionStart = sessionStart || Date.now();
    btnListen.className = 'btn-listen stop';
    btnListenIcon.textContent = '⏸';
    btnListenLabel.textContent = 'Pausar';

    startMicRecognition();
    startTabCapture();
    startSentimentAI();

    resetSilenceTimer();
    window.parent?.postMessage({ type: 'seazone-status', listening: true }, '*');
  }

  function stopListening() {
    isListening = false;
    clearTimeout(silenceTimer);
    btnListen.className = 'btn-listen start';
    btnListenIcon.textContent = '▶';
    btnListenLabel.textContent = 'Iniciar';

    stopMicRecognition();
    stopTabCapture();
    stopSentimentAI();

    saveToLocalStorage();
    window.parent?.postMessage({ type: 'seazone-status', listening: false }, '*');
  }

  function clearSession() {
    transcriptEntries = [];
    sessionStart = null;
    lastSpeaker = null;
    sentimentScore = 0;
    aiSentimentScore = 0;
    aiSentimentLabel = 'neutral';
    renderThermometer();
    renderSentimentCard();
    transcriptEl.querySelectorAll('.transcript-line').forEach(el => el.remove());
    transcriptEmpty.style.display = '';
    popupsEl.querySelectorAll('.popup').forEach(el => el.remove());
    popupsEmpty.style.display = '';
    activePopups = 0;
    resetChecklist();
  }

  // ===== localStorage =====
  function saveToLocalStorage() {
    if (!sessionStart || transcriptEntries.length === 0) return;
    const key = getSessionKey();
    const data = {
      sessionStart,
      savedAt: Date.now(),
      meetUrl: window.location !== window.parent.location ? document.referrer : window.location.href,
      entries: transcriptEntries,
      checklist: { ...dynamicChecklistState },
      sentimentScore,
    };
    try {
      localStorage.setItem(key, JSON.stringify(data));
      const index = JSON.parse(localStorage.getItem('seazone_sessions') || '[]');
      if (!index.includes(key)) {
        index.push(key);
        localStorage.setItem('seazone_sessions', JSON.stringify(index));
      }
    } catch (e) {
      console.warn('localStorage save failed:', e);
    }
  }

  // ===== Conclude Meeting =====
  async function concludeMeeting() {
    if (isListening) stopListening();

    const total = dynamicChecklistItems.length;
    let totalWeight = 0, doneWeight = 0;
    dynamicChecklistItems.forEach((item, idx) => {
      const w = item.weight || 1;
      totalWeight += w;
      if (dynamicChecklistState[idx]) doneWeight += w;
    });
    const done = Object.values(dynamicChecklistState).filter(Boolean).length;
    const finalScore = totalWeight > 0 ? Math.round((doneWeight / totalWeight) * 100) : 0;

    // Build detailed checklist items with weights for template-based scoring
    const checklistItemsPayload = dynamicChecklistItems.map((item, idx) => ({
      id: item.id || null,
      label: item.label,
      weight: item.weight || 1,
      checked: !!dynamicChecklistState[idx],
    }));

    // Build payload for Supabase — score is the weighted checklist score
    const meetingPayload = {
      title: `Reunião ${localParticipantName || 'Vendedor'} - ${new Date().toLocaleDateString('pt-BR')} ${new Date().toLocaleTimeString('pt-BR', {hour:'2-digit', minute:'2-digit'})}`,
      transcript: transcriptEntries,
      checklistItems: checklistItemsPayload,
      templateId: activeTemplate?.id || null,
      score: finalScore,
      duration_minutes: sessionStart ? Math.round((Date.now() - sessionStart) / 60000) : 0,
      started_at: sessionStart ? new Date(sessionStart).toISOString() : new Date().toISOString(),
      status: 'completed',
      has_local_transcription: true,
      localParticipantName: localParticipantName || 'Vendedor',
      participant_emails: participantEmails,
      source: 'Sales Coach AI',
      tags: ['Sales Coach AI', 'Extensão Chrome'],
    };

    // Send to Supabase Edge Function BEFORE local save
    const btnConclude = document.getElementById('btn-conclude');
    try {
      if (btnConclude) { btnConclude.disabled = true; btnConclude.textContent = '⏳ Salvando...'; }

      const response = await fetch(`${SUPABASE_URL}/functions/v1/salvar-reuniao-da-extensao`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
        },
        body: JSON.stringify(meetingPayload),
      });

      const data = await response.json();

      if (response.ok) {
        if (btnConclude) btnConclude.textContent = '✅ Reunião salva!';
        showPopup('positive', '✅', 'Reunião salva no dashboard!', `Score: ${finalScore}% • ${done}/${total} itens`, 4000);
        console.log('[concludeMeeting] saved:', data);
      } else {
        if (btnConclude) btnConclude.textContent = '❌ Erro ao salvar';
        showPopup('objection', '❌', 'Erro ao salvar', data.error || 'Tente novamente.', 4000);
        console.error('[concludeMeeting] error:', data);
      }
    } catch (err) {
      console.error('[concludeMeeting] fetch error:', err);
      if (btnConclude) btnConclude.textContent = '⚠️ Salvo localmente';
      showPopup('objection', '⚠️', 'Erro de conexão', 'Dados salvos localmente.', 4000);
    }

    // Save to localStorage after API call
    saveToLocalStorage();

    // Notify parent (content.js)
    const sessionData = {
      type: 'seazone-conclude',
      score: finalScore,
      checklist: { ...dynamicChecklistState },
      sentimentScore,
      aiSentimentScore,
      transcriptCount: transcriptEntries.length,
      duration: sessionStart ? Math.round((Date.now() - sessionStart) / 60000) : 0,
    };
    window.parent?.postMessage(sessionData, '*');

    console.log('[sidebar] Meeting concluded:', sessionData);
  }

  // ===== Events =====
  btnListen.addEventListener('click', () => {
    isListening ? stopListening() : startListening();
  });

  btnClear.addEventListener('click', () => {
    if (isListening) stopListening();
    clearSession();
  });

  btnClose.addEventListener('click', () => {
    if (isListening) stopListening();
    sendExtensionEvent('close');
    window.parent?.postMessage({ type: 'seazone-close' }, '*');
  });

  btnConclude.addEventListener('click', () => {
    sendExtensionEvent('close');
    concludeMeeting();
  });

  // ===== Mute State Handler =====
  function handleMuteChange(muted) {
    isMicMuted = muted;
    if (!isListening) return;

    if (muted) {
      try { micRecognition?.stop(); } catch (e) {}
      micActive = false;
      updateBadge('mic', false);
      if (badgeMic) {
        badgeMic.innerHTML = '<span class="badge-dot"></span> 🔇 Mutado';
      }
      console.log('[mic] Paused — Meet mic muted');
    } else {
      if (micRecognition) {
        try { micRecognition.start(); } catch (e) {}
      } else {
        startMicRecognition();
      }
      updateBadge('mic', true);
      if (badgeMic) {
        badgeMic.innerHTML = '<span class="badge-dot"></span> 🎤 Mic';
      }
      console.log('[mic] Resumed — Meet mic unmuted');
    }
  }

  window.addEventListener('message', (e) => {
    if (e.data?.type === 'seazone-listen') {
      e.data.listening ? startListening() : stopListening();
    }
    if (e.data?.type === 'seazone-mute') {
      handleMuteChange(e.data.isMuted);
    }
    if (e.data?.type === 'seazone-local-name' && e.data.name) {
      localParticipantName = e.data.name;
      console.log('[sidebar] Local name set:', localParticipantName);
      // Re-fetch template with actual participant name for better matching
      if (!activeTemplate) fetchTemplate(localParticipantName);
    }
    if (e.data?.type === 'seazone-caption' && e.data.text) {
      // Caption text from Google Meet's built-in captions (scraped by content.js)
      const speaker = e.data.speaker || 'Cliente';
      addTranscriptLine(e.data.text, speaker, true, false);
      updateBadge('tab', true);
      console.log('[caption] Received:', speaker, '-', e.data.text.substring(0, 40));
    }
    if (e.data?.type === 'seazone-speaker' && e.data.name) {
      // Only update if the speaker is NOT the local participant (seller)
      if (e.data.name !== localParticipantName) {
        activeSpeakerName = e.data.name;
        console.log('[sidebar] Active speaker (client):', activeSpeakerName);
      }
    }
    if (e.data?.type === 'seazone-participant-emails' && Array.isArray(e.data.emails)) {
      // Merge unique emails
      e.data.emails.forEach(email => {
        if (!participantEmails.includes(email)) participantEmails.push(email);
      });
      console.log('[sidebar] Participant emails:', participantEmails);
    }
  });

  // ===== Extension Event Tracking =====
  function sendExtensionEvent(eventType) {
    const name = localParticipantName || 'Desconhecido';
    fetch(`${SUPABASE_URL}/functions/v1/extension-event`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'apikey': SUPABASE_ANON_KEY,
        'Authorization': `Bearer ${SUPABASE_ANON_KEY}`,
      },
      body: JSON.stringify({ event_type: eventType, user_name: name }),
    }).catch(err => console.warn('[event]', eventType, 'failed:', err));
  }

  // Send "open" event on sidebar load
  sendExtensionEvent('open');

  // Init thermometer
  renderThermometer();
})();
